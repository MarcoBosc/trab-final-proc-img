import React, { useState, useEffect } from 'react'
import { TabPanel } from '@mui/lab'
import { Button, TextField } from '@mui/material'
import { Images, Result } from 'src/constants/types'
import { useHistogramEqualization, drawHistogram, computeHistogram } from 'src/hooks/histogram'
import './styles.scss'

type Props = {
    images: Images
    tabValue: string
    updateResult: (value: Result) => void
};

export const TabHistogramEqualization = ({
    images,
    tabValue,
    updateResult
}: Props) => {

    const { one: imageOne } = images

    const [histogram, setHistogram] = useState<number[]>([])
    const [equalizedImage, setEqualizedImage] = useState<ImageData | null>(null)

    useEffect(() => {
        const hist = computeHistogram(imageOne)
        setHistogram(hist)
        drawHistogram('originalHistogram', hist)
    }, [imageOne])

    const applyHistogramEqualization = () => {
        const result = useHistogramEqualization(imageOne)
        setEqualizedImage(result)
        const hist = computeHistogram(result)
        drawHistogram('equalizedHistogram', hist)

        updateResult({
            description: 'Equalização de Histograma',
            value: result
        })
    }

    return (
        <TabPanel id='histogram-equalization' value={tabValue}>
            <Button
                variant='contained'
                onClick={applyHistogramEqualization}
            >
                Equalizar Histograma
            </Button>
            <div className='histogram-container'>
                <canvas id='originalHistogram' width='256' height='100'></canvas>
                <canvas id='equalizedHistogram' width='256' height='100'></canvas>
            </div>
            {equalizedImage && (
                <img
                    src={URL.createObjectURL(new Blob([equalizedImage.data.buffer]))}
                    alt='Equalized'
                />
            )}
        </TabPanel>
    )
}
