import { useState } from 'react'
import { TabPanel } from '@mui/lab'
import { Button, Slider } from '@mui/material'
import { adjustBrightness } from 'src/hooks/brightness'
import { Images, Result } from 'src/constants/types'
import './styles.scss'

type Props = {
    images: Images
    tabValue: string
    updateResult: (value: Result) => void
};

export const TabBrightnessAdjustment = ({ images, tabValue, updateResult }: Props) => {
    const { one: imageOne } = images
    const [brightness, setBrightness] = useState<number>(0)

    const applyBrightness = () => {
        updateResult({
            description: `Ajuste de Brilho (${brightness})`,
            value: adjustBrightness(imageOne, brightness),
        })
    }

    return (
        <TabPanel id='brightness-adjustment' value={tabValue}>
            <div className='brightness-slider'>
                <Slider
                    value={brightness}
                    min={-255}
                    max={255}
                    step={1}
                    onChange={(_, newValue) => setBrightness(newValue as number)}
                    aria-labelledby='brightness-slider'
                />
            </div>
            <Button
                variant='contained'
                onClick={applyBrightness}
            >
                Aplicar Brilho
            </Button>
        </TabPanel>
    )
}
