import { TabPanel } from '@mui/lab'
import { Button, Radio, RadioGroup, FormControl, FormLabel, FormControlLabel } from '@mui/material'
import { useState } from 'react'
import flipImage from 'src/hooks/flipImage'
import { Images, Result } from 'src/constants/types'
import './styles.scss'

type Props = {
    images: Images;
    tabValue: string;
    updateResult: (value: Result) => void;
};

export const TabFlip = ({ images, tabValue, updateResult }: Props) => {
    const { one: imageOne } = images

    const [flipDirection, setFlipDirection] = useState<'horizontal' | 'vertical'>('horizontal')

    const handleFlip = () => {
        const resultImage = flipImage(imageOne, flipDirection)
        updateResult({
            description: `Flip ${flipDirection === 'horizontal' ? 'Horizontal' : 'Vertical'}`,
            value: resultImage
        })
    }

    return (
        <TabPanel id='flip' value={tabValue}>
            <FormControl component="fieldset" className="form-control">
                <FormLabel component="legend">Escolha a direção do flip</FormLabel>
                <RadioGroup value={flipDirection} onChange={(e) => setFlipDirection(e.target.value as 'horizontal' | 'vertical')} className="radio-group">
                    <FormControlLabel value="horizontal" control={<Radio />} label="Horizontal" className="radio-label" />
                    <FormControlLabel value="vertical" control={<Radio />} label="Vertical" className="radio-label" />
                </RadioGroup>
            </FormControl>
            <Button variant="contained" onClick={handleFlip} className="flip-button">
                Flipar Imagem
            </Button>
        </TabPanel>
    )
}
