const flipImage = (image: ImageData, direction: 'horizontal' | 'vertical'): ImageData => {
    const { width, height, data } = image
    const flippedData = new Uint8ClampedArray(data.length)

    for (let y = 0; y < height; y++) {
        for (let x = 0; x < width; x++) {
            const srcIndex = (y * width + x) * 4
            let destX = x
            let destY = y

            if (direction === 'horizontal') {
                destX = width - 1 - x
            } else if (direction === 'vertical') {
                destY = height - 1 - y
            }

            const destIndex = (destY * width + destX) * 4
            flippedData[destIndex] = data[srcIndex]
            flippedData[destIndex + 1] = data[srcIndex + 1]
            flippedData[destIndex + 2] = data[srcIndex + 2]
            flippedData[destIndex + 3] = data[srcIndex + 3]
        }
    }

    return new ImageData(flippedData, width, height)
}

export default flipImage
