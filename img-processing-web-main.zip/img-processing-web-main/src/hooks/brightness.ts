const adjustBrightness = (image: ImageData, brightness: number): ImageData => {
    const { width, height, data } = image
    const resultData = new Uint8ClampedArray(data.length)

    for (let i = 0; i < data.length; i += 4) {
        resultData[i] = Math.min(255, Math.max(0, data[i] + brightness)) // Red
        resultData[i + 1] = Math.min(255, Math.max(0, data[i + 1] + brightness)) // Green
        resultData[i + 2] = Math.min(255, Math.max(0, data[i + 2] + brightness)) // Blue
        resultData[i + 3] = data[i + 3] // Alpha
    }

    return new ImageData(resultData, width, height)
}

export { adjustBrightness }
