interface ImageDataType {
    width: number
    height: number
    data: Uint8ClampedArray
}

const useHistogramEqualization = (image: ImageDataType): ImageData => {
    const { width, height, data } = image
    const resultData = new Uint8ClampedArray(data.length)

    // Histograma para os três canais
    const histogram = [new Array(256).fill(0), new Array(256).fill(0), new Array(256).fill(0)]

    // Preenchendo o histograma
    for (let i = 0; i < data.length; i += 4) {
        histogram[0][data[i]]++
        histogram[1][data[i + 1]]++
        histogram[2][data[i + 2]]++
    }

    // Função cumulativa de distribuição
    const cdf = [new Array(256).fill(0), new Array(256).fill(0), new Array(256).fill(0)]
    for (let i = 1; i < 256; i++) {
        cdf[0][i] = cdf[0][i - 1] + histogram[0][i]
        cdf[1][i] = cdf[1][i - 1] + histogram[1][i]
        cdf[2][i] = cdf[2][i - 1] + histogram[2][i]
    }

    // Normalizando a CDF
    const cdfMin = [Math.min(...cdf[0].filter(val => val > 0)), Math.min(...cdf[1].filter(val => val > 0)), Math.min(...cdf[2].filter(val => val > 0))]
    const numPixels = width * height
    const lookupTable = [new Array(256), new Array(256), new Array(256)]
    for (let i = 0; i < 256; i++) {
        lookupTable[0][i] = Math.round((cdf[0][i] - cdfMin[0]) / (numPixels - cdfMin[0]) * 255)
        lookupTable[1][i] = Math.round((cdf[1][i] - cdfMin[1]) / (numPixels - cdfMin[1]) * 255)
        lookupTable[2][i] = Math.round((cdf[2][i] - cdfMin[2]) / (numPixels - cdfMin[2]) * 255)
    }

    // Aplicando a equalização
    for (let i = 0; i < data.length; i += 4) {
        resultData[i] = lookupTable[0][data[i]]
        resultData[i + 1] = lookupTable[1][data[i + 1]]
        resultData[i + 2] = lookupTable[2][data[i + 2]]
        resultData[i + 3] = data[i + 3]
    }

    return new ImageData(resultData, width, height)
}

const drawHistogram = (canvasId: string, histogram: number[]): void => {
    const canvas = document.getElementById(canvasId) as HTMLCanvasElement | null
    if (!canvas) {
        console.error(`Canvas element with id '${canvasId}' not found.`)
        return
    }

    const ctx = canvas.getContext('2d')
    if (!ctx) {
        console.error('Failed to get canvas 2D context.')
        return
    }

    ctx.clearRect(0, 0, canvas.width, canvas.height)

    const barWidth = canvas.width / 256
    for (let i = 0; i < 256; i++) {
        const height = histogram[i] / Math.max(...histogram) * canvas.height
        ctx.fillStyle = 'black'
        ctx.fillRect(i * barWidth, canvas.height - height, barWidth, height)
    }
}

const computeHistogram = (image: ImageDataType): number[] => {
    const { data } = image
    const histogram = new Array(256).fill(0)

    for (let i = 0; i < data.length; i += 4) {
        histogram[data[i]]++
    }

    return histogram
}

export { useHistogramEqualization, drawHistogram, computeHistogram }
