export type Result = {
    description: string
    value: ImageData
}