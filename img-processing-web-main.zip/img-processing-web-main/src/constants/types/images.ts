export type Images = {
    one: ImageData
    two?: ImageData
}