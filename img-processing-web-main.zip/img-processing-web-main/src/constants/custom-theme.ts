import { Theme } from '@mui/material'
import { createTheme } from '@mui/material/styles'
import { blue, green, pink } from '@mui/material/colors'
import { light } from '@mui/material/styles/createPalette'

const customTheme: Theme = createTheme({
    palette: {
        mode: 'light',
        primary: green,
        secondary: green
    }
})

export default customTheme